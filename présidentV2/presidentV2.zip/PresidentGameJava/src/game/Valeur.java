package carte;

public class Valeur {

}
