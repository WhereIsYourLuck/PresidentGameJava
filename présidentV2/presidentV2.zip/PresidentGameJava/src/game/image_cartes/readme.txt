these are the cards
