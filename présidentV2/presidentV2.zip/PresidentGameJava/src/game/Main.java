package game;

import president_GUI.Fenetre_debut_jeu;
import president_GUI.Fenetre_fin_jeu;
import president_GUI.WindowGame;

public class Main {

    public static void main(String[] args) throws Exception {
    Game game = new Game();
    Fenetre_debut_jeu jeu = new Fenetre_debut_jeu();
    //WindowGame jeu = new WindowGame();
    
    }
}
