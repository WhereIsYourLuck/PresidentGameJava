package game;

import president_GUI.Fenetre_debut_jeu;
import president_GUI.Fenetre_fin_jeu;

import java.util.Comparator;


public class Main {

    public static void main(String[] args) throws Exception {
       Fenetre_debut_jeu jeu = new Fenetre_debut_jeu();
    	//Game partie = new Game();
        //Fenetre_fin_jeu end = new Fenetre_fin_jeu(partie);
    }
}
