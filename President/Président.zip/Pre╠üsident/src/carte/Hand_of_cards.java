package carte;

public class Hand_of_cards {
	
	private String[] hand;
	public void hand_of_cards(Deck_card deck) {
	

		
	}
}
