package carte;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class Deck_card{
	
	private String[] couleurs = {"Coeur","Pic","Carreau","Trefle"};
	private int[] valeurs = {1,2,3,4,5,6,7,8,9,10,11,12,13};
	
	int nbCartes = couleurs.length * valeurs.length;
	private static String[] deck;
	
	public Deck_card() {
		/*
		String[] deck = new String[nbCartes];
		for (int i = 0; i < valeurs.length; i++) {
            for (int j = 0; j < couleurs.length; j++) {
                deck[couleurs.length*i + j] = valeurs[i] + " of " + couleurs[j];
            }
        }
		
		  // shuffle
        for (int i = 0; i < nbCartes; i++) {
            int r = i + (int) (Math.random() * (nbCartes-i));
            String temp = deck[r];
            deck[r] = deck[i];
            deck[i] = temp;
        }
        
        
          
     // print shuffled deck
        for (int i = 0; i < nbCartes; i++) {
            System.out.println(deck[i]);
        }
        
        
        */
        
	}

	
	
	
	public static void getDeck() {
		System.out.println(deck[3]);
		//return deck[3];
		
	}




	public String[] Deck_card() {
		// TODO Auto-generated method stub

		String[] deck = new String[nbCartes];
		for (int i = 0; i < valeurs.length; i++) {
            for (int j = 0; j < couleurs.length; j++) {
                deck[couleurs.length*i + j] = valeurs[i] + " of " + couleurs[j];
            }
        }
		
		  // shuffle
        for (int i = 0; i < nbCartes; i++) {
            int r = i + (int) (Math.random() * (nbCartes-i));
            String temp = deck[r];
            deck[r] = deck[i];
            deck[i] = temp;
        }
        
        /*
          
     // print shuffled deck
        for (int i = 0; i < nbCartes; i++) {
            System.out.println(deck[i]);
        }
        */
        /*
        for (int i = 0; i < nbCartes; i++) {
            System.out.println(deck[i]);
        }*/
		return deck;
        
        
	}




	
	
	
	
	

}
