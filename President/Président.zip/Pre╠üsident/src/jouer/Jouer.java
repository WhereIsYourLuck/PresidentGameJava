package jouer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import carte.Deck_card;

public class Jouer {
	int joueurId;
	
public void hand_of_cards(int idplayer) {
	joueurId = idplayer;
	
		
	}
public static void distributeHand() {
	Deck_card cards = new Deck_card();
	String[] totalHand = cards.Deck_card();
	
	String[] myHand = new String[13];
	int count = 0;

	
	for (int i = 0; i < myHand.length; i++) {
		myHand[i] = totalHand[i];
		//System.out.println(myHand[i].toString());
		List<String> list = new ArrayList<String>(Arrays.asList(totalHand));
		list.remove(2);
		totalHand = list.toArray(new String[0]);
	}System.out.println(totalHand[0]);
	
	
}
	
	


}
