package president_GUI;



import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.Container;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import game.Card;
import game.*;


public class WindowGame{
			Game game;

		/**
		 * 
		 */

		public WindowGame(Game g) {
				//debug affichage
			this.game = g;
				Border blackline = BorderFactory.createLineBorder(Color.BLACK);
				//image.setBorder(blackline);
			
				JFrame frame = new JFrame("Pr�sident");
				//make sure it quits when x is clicked
				frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				frame.setLayout(new BorderLayout());
				//add image 
				JPanel panel_image = new JPanel();
				ImageIcon icone = new ImageIcon("images/b1fv.png");
				JLabel image = new JLabel(icone);
				image.setSize(icone.getIconHeight(),icone.getIconHeight());
				frame.add(image, BorderLayout.NORTH);
				
				
				//add button distribute  
			    JPanel panel = new JPanel();
				JButton button = new JButton("Distribute");
				button.setSize(100,100);
				panel.add(button, BorderLayout.NORTH);
				frame.add(panel, BorderLayout.CENTER);
				frame.pack();
				frame.setVisible(true);
				//set default size of window
				frame.setSize(1000, 550);
				frame.setVisible(true);
				
				//Action listener for distribute
				button.addActionListener(new ActionListener() {
					@Override 
					public void actionPerformed(ActionEvent e) {
					    //distribution des cartes
						clear_JFrame(frame);
						affiche_jeux(frame);
						frame.setMinimumSize(new Dimension(1000,400));
						//mettre_fondMoche(frame);
						}
				});
				
				
				
				
			
		}
		
		
		
		public static void clear_JFrame(JFrame fenetre) {
			fenetre.getContentPane().removeAll();
			fenetre.repaint();
		}
		/*
		public static void mettre_fondMoche(JFrame fenetre) {
			fenetre.setContentPane(new JLabel(new ImageIcon("images/Tapis.jpg")));
		}
		*/
		public static void setImage_toCard(Player jouer) {
		
		}
		
		
		
		public void affiche_jeux(JFrame fenetre) {
			//debug affichage
			Border blackline = BorderFactory.createLineBorder(Color.BLACK);
			
			//variables 
			int carte_restante_joueur1 = 100;
			int carte_restante_joueur3 = game.p3.getHand().size();
			int carte_restante_joueur4 = 8;
			
			//minimum size of JFrame
			fenetre.setMinimumSize(new Dimension(100,100));
			//jeux 1
			
			JPanel panel_image1 = new JPanel();
			ImageIcon icone1 = new ImageIcon("images/b2fv.png");
			JLabel image1 = new JLabel(icone1);
			image1.setSize(icone1.getIconHeight(),icone1.getIconHeight());
			fenetre.add(image1, BorderLayout.NORTH);
			image1.setText("<html>cartes restante : <br/>" + carte_restante_joueur1 + "</html>" );
			
			/*
			 * Jeu du joueur utile
			 */
			
			//jeux 2
			
			/*
			System.out.println(this.game.p1.getHand().get(0).getImage());
			System.out.println(game.p1.toString());
			ImageIcon icone2 = new ImageIcon(this.game.p1.getHand().get(0).getImage());
			JPanel panel_image2 = new JPanel();
			JLabel image2 = new JLabel(icone2);
			image2.setSize(icone2.getIconHeight(),icone2.getIconHeight());
			//fenetre.add(image2, BorderLayout.SOUTH);
			*/
			//image2.setBorder(blackline);
			
			System.out.println(this.game.p1.getHand().get(1).getImage());
			ImageIcon icone100 = new ImageIcon(this.game.p1.getHand().get(1).getImage());
			JPanel panel_Jouer = new JPanel();
			JLabel image100 = new JLabel(icone100);
			image100.setSize(icone100.getIconHeight(),icone100.getIconHeight());
			panel_Jouer.add(image100);
			
			
			ImageIcon icone101 = new ImageIcon(this.game.p1.getHand().get(2).getImage());
			JLabel image101 = new JLabel(icone101);
			image101.setSize(icone101.getIconHeight(),icone101.getIconHeight());
			panel_Jouer.add(image101);
			
			ImageIcon icone102 = new ImageIcon(this.game.p1.getHand().get(3).getImage());
			JLabel image102 = new JLabel(icone102);
			image102.setSize(icone102.getIconHeight(),icone102.getIconHeight());
			panel_Jouer.add(image102);
			
			ImageIcon icone103 = new ImageIcon(this.game.p1.getHand().get(4).getImage());
			JLabel image103 = new JLabel(icone103);
			image103.setSize(icone103.getIconHeight(),icone103.getIconHeight());
			panel_Jouer.add(image103);
			
			ImageIcon icone104 = new ImageIcon(this.game.p1.getHand().get(5).getImage());
			JLabel image104 = new JLabel(icone104);
			image104.setSize(icone104.getIconHeight(),icone104.getIconHeight());
			panel_Jouer.add(image104);
			
			ImageIcon icone105 = new ImageIcon(this.game.p1.getHand().get(6).getImage());
			JLabel image105 = new JLabel(icone105);
			image105.setSize(icone105.getIconHeight(),icone105.getIconHeight());
			panel_Jouer.add(image105);
			
			ImageIcon icone106 = new ImageIcon(this.game.p1.getHand().get(7).getImage());
			JLabel image106 = new JLabel(icone106);
			image106.setSize(icone106.getIconHeight(),icone106.getIconHeight());
			panel_Jouer.add(image106);
			
			ImageIcon icone107 = new ImageIcon(this.game.p1.getHand().get(8).getImage());
			JLabel image107 = new JLabel(icone107);
			image107.setSize(icone107.getIconHeight(),icone107.getIconHeight());
			panel_Jouer.add(image107);
			
			ImageIcon icone108 = new ImageIcon(this.game.p1.getHand().get(9).getImage());
			JLabel image108 = new JLabel(icone108);
			image108.setSize(icone108.getIconHeight(),icone108.getIconHeight());
			panel_Jouer.add(image108);
			
			ImageIcon icone109 = new ImageIcon(this.game.p1.getHand().get(10).getImage());
			JLabel image109 = new JLabel(icone109);
			image109.setSize(icone109.getIconHeight(),icone109.getIconHeight());
			panel_Jouer.add(image109);
			
			ImageIcon icone110 = new ImageIcon(this.game.p1.getHand().get(11).getImage());
			JLabel image110 = new JLabel(icone110);
			image110.setSize(icone110.getIconHeight(),icone110.getIconHeight());
			panel_Jouer.add(image110);
			
			ImageIcon icone111 = new ImageIcon(this.game.p1.getHand().get(12).getImage());
			JLabel image111 = new JLabel(icone111);
			image111.setSize(icone111.getIconHeight(),icone111.getIconHeight());
			panel_Jouer.add(image111);
			
			ImageIcon icone112 = new ImageIcon(this.game.p1.getHand().get(0).getImage());
			JLabel image112 = new JLabel(icone112);
			image112.setSize(icone112.getIconHeight(),icone112.getIconHeight());
			panel_Jouer.add(image112);
			
			fenetre.add(panel_Jouer, BorderLayout.SOUTH);
			//image19.setBorder(blackline);
			
			/*
			 * Fin Jeu du joueur utile
			 */
			
			//jeux 3
			ImageIcon icone3 = new ImageIcon("images/b2fv.png");
			JPanel panel_image3 = new JPanel();
			JLabel image3 = new JLabel(icone3);
			image3.setSize(icone3.getIconHeight(),icone3.getIconHeight());
			fenetre.add(image3, BorderLayout.EAST);
			image3.setText("<html>cartes restante : <br/>" + carte_restante_joueur3 + "</html>" );
			//image3.setBorder(blackline);
					
			//jeux 4
			ImageIcon icone4 = new ImageIcon("images/b2fv.png");
			JPanel panel_image4 = new JPanel();
			JLabel image4 = new JLabel(icone4);
			image4.setSize(icone4.getIconHeight(),icone4.getIconHeight());
			fenetre.add(image4, BorderLayout.WEST);
			image4.setText("<html>cartes restante : <br/>" + carte_restante_joueur4 + "</html>" );
					//image4.setBorder(blackline);
			
			
		}

	}


